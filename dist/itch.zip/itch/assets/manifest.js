window.ASSET_LIST = [];
